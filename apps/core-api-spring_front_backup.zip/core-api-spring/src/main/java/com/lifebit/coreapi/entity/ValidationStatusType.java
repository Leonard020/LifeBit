package com.lifebit.coreapi.entity;

public enum ValidationStatusType {
    PENDING,
    VALIDATED,
    REJECTED
} 