package com.lifebit.coreapi.entity;

public enum InputSourceType {
    VOICE,
    TYPING
} 