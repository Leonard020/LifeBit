package com.lifebit.coreapi.entity;

public enum BodyPartType {
    chest,
    back,
    legs,
    shoulders,
    abs,
    arms,
    cardio
} 