package com.lifebit.coreapi.entity;

public enum MealTimeType {
    breakfast,
    lunch,
    dinner,
    snack
} 