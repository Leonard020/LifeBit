package com.lifebit.coreapi.entity;

public enum BadgeType {
    bronze, silver, gold, platinum
} 