package com.lifebit.coreapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
